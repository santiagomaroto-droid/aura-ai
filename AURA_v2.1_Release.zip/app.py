"""
AURA Interactive Studio (Web Dashboard)
=======================================
A modern, visual web application to interact directly with AURA-Matrix v2.1.
Zero external dependencies (uses Python's built-in http.server).
"""

import os
import json
import time
import random
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
import torch
import torch.nn.functional as F

from aura_matrix_v2 import AURAv2Model
from train_v2_text import get_corpus, CharTokenizer


# Load Modern Model and Tokenizer globally
print("[AURA Studio] Cargando modelo moderno y tokenizer...")
device = torch.device("cpu")

from train_v2_modern import ModernCharTokenizer

if os.path.exists("tokenizer_moderno.json"):
    tokenizer = ModernCharTokenizer.load("tokenizer_moderno.json")
    print(f"[AURA Studio] Tokenizer moderno cargado (Vocab: {tokenizer.vocab_size})")
else:
    corpus_text = get_corpus()
    tokenizer = CharTokenizer(corpus_text)

model = AURAv2Model(
    vocab_size=tokenizer.vocab_size,
    d_model=96,
    n_layers=3,
    n_heads=4,
    d_k=24,
    d_v=24,
).to(device)

checkpoint_path = "aura_v2_modern_checkpoint.pt"
if not os.path.exists(checkpoint_path):
    checkpoint_path = "aura_v2_text_checkpoint.pt"

if os.path.exists(checkpoint_path):
    model.load_state_dict(torch.load(checkpoint_path, map_location=device))
    print(f"[AURA Studio] Checkpoint cargado exitosamente: {checkpoint_path}")
else:
    print(f"[AURA Studio] AVISO: No se encontro checkpoint, usando pesos iniciales.")

model.eval()



@torch.no_grad()
def run_generation(prompt: str, max_tokens: int = 60, temperature: float = 0.75, top_k: int = 25):
    t0 = time.perf_counter()
    ids = tokenizer.encode(prompt).unsqueeze(0).to(device)

    # 1. Warm-up state
    h = model.embed(ids)
    states = []
    for block in model.blocks:
        h, state = block(h)
        states.append(state)
    h = model.norm(h)

    logits = model.head(h[:, -1, :]) / max(temperature, 1e-4)
    if top_k:
        v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
        logits[logits < v[:, [-1]]] = -float("inf")
    probs = F.softmax(logits, dim=-1)
    tok = torch.multinomial(probs, 1)
    generated = [tok]

    # 2. O(1) step generation
    for _ in range(max_tokens - 1):
        h_t = model.embed(tok).squeeze(1)
        new_states = []
        for i, block in enumerate(model.blocks):
            res, new_s = block.cell(block.norm1(h_t).unsqueeze(1), states[i])
            h_t = h_t + res.squeeze(1)
            h_t = h_t + block.mlp(block.norm2(h_t))
            new_states.append(new_s)
        states = new_states

        h_t = model.norm(h_t)
        logits = model.head(h_t) / max(temperature, 1e-4)
        if top_k:
            v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
            logits[logits < v[:, [-1]]] = -float("inf")
        probs = F.softmax(logits, dim=-1)
        tok = torch.multinomial(probs, 1)
        generated.append(tok)

    elapsed_ms = (time.perf_counter() - t0) * 1000
    all_tokens = torch.cat([ids, torch.cat(generated, dim=1)], dim=1)
    full_text = tokenizer.decode(all_tokens)
    new_text = tokenizer.decode(torch.cat(generated, dim=1))

    # Equivalent KV Cache size for a Transformer at this length
    total_len = all_tokens.shape[1]
    tf_kv_bytes = 2 * 3 * 1 * total_len * 96 * 4  # 2 * layers * batch * seq * d_model * 4

    return {
        "full_text": full_text,
        "new_text": new_text,
        "tokens_generated": len(generated),
        "total_context": total_len,
        "elapsed_ms": round(elapsed_ms, 1),
        "ms_per_token": round(elapsed_ms / len(generated), 2),
        "aura_memory_kb": 54.0,  # Constant!
        "transformer_kv_kb": round(tf_kv_bytes / 1024, 1),
    }


HTML_CONTENT = """<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AURA Studio 🌌 - Adaptive Unitary Resonant Architecture</title>
  <style>
    :root {
      --bg: #090d16;
      --card-bg: rgba(16, 24, 40, 0.75);
      --card-border: rgba(56, 189, 248, 0.18);
      --primary: #38bdf8;
      --primary-glow: rgba(56, 189, 248, 0.4);
      --accent: #a855f7;
      --accent-glow: rgba(168, 85, 247, 0.4);
      --success: #10b981;
      --text: #f1f5f9;
      --text-muted: #94a3b8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; }
    body {
      background: radial-gradient(circle at 50% 0%, #1e1b4b 0%, var(--bg) 60%);
      color: var(--text);
      min-height: 100vh;
      padding: 24px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .container { max-width: 1050px; width: 100%; display: flex; flex-direction: column; gap: 24px; }
    header {
      text-align: center;
      padding: 20px 0;
      border-bottom: 1px solid var(--card-border);
      position: relative;
    }
    .badge {
      display: inline-block;
      background: linear-gradient(135deg, rgba(56, 189, 248, 0.2), rgba(168, 85, 247, 0.2));
      border: 1px solid var(--primary);
      padding: 6px 14px;
      border-radius: 999px;
      font-size: 0.82rem;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      font-weight: 700;
      color: var(--primary);
      margin-bottom: 12px;
    }
    h1 {
      font-size: 2.4rem;
      font-weight: 800;
      background: linear-gradient(135deg, #38bdf8 0%, #c084fc 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 8px;
    }
    p.subtitle { color: var(--text-muted); font-size: 1.05rem; }
    
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
    }
    .stat-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 14px;
      padding: 16px 20px;
      backdrop-filter: blur(12px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.3);
    }
    .stat-title { font-size: 0.85rem; color: var(--text-muted); text-transform: uppercase; font-weight: 600; margin-bottom: 6px; }
    .stat-value { font-size: 1.6rem; font-weight: 700; color: #fff; }
    .stat-highlight { color: var(--primary); font-size: 0.85rem; font-weight: 500; margin-top: 4px; }

    .main-grid {
      display: grid;
      grid-template-columns: 1fr 1.2fr;
      gap: 24px;
    }
    @media (max-width: 820px) { .main-grid { grid-template-columns: 1fr; } }

    .card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 24px;
      backdrop-filter: blur(14px);
      display: flex;
      flex-direction: column;
      gap: 18px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    }
    .card h2 { font-size: 1.3rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }

    textarea {
      width: 100%;
      height: 120px;
      background: rgba(10, 16, 29, 0.85);
      border: 1px solid rgba(56, 189, 248, 0.25);
      border-radius: 10px;
      color: #fff;
      padding: 14px;
      font-size: 0.98rem;
      resize: vertical;
      outline: none;
      transition: border 0.2s;
    }
    textarea:focus { border-color: var(--primary); box-shadow: 0 0 12px var(--primary-glow); }

    .presets { display: flex; flex-wrap: wrap; gap: 8px; }
    .preset-btn {
      background: rgba(56, 189, 248, 0.1);
      border: 1px solid rgba(56, 189, 248, 0.25);
      color: var(--primary);
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 0.82rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .preset-btn:hover { background: rgba(56, 189, 248, 0.25); transform: translateY(-1px); }

    .controls { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .control-group label { display: block; font-size: 0.82rem; color: var(--text-muted); margin-bottom: 6px; }
    .control-group input[type="range"] { width: 100%; accent-color: var(--primary); }
    .control-val { font-weight: 700; color: var(--primary); float: right; }

    button.run-btn {
      background: linear-gradient(135deg, #0284c7 0%, #9333ea 100%);
      border: none;
      color: #fff;
      padding: 14px;
      border-radius: 10px;
      font-size: 1rem;
      font-weight: 700;
      cursor: pointer;
      box-shadow: 0 4px 20px var(--primary-glow);
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    button.run-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 24px var(--accent-glow); }
    button.run-btn:disabled { opacity: 0.6; cursor: not-allowed; }

    .output-box {
      background: rgba(10, 16, 29, 0.85);
      border: 1px solid rgba(56, 189, 248, 0.2);
      border-radius: 12px;
      padding: 18px;
      min-height: 200px;
      max-height: 380px;
      overflow-y: auto;
      font-size: 1.05rem;
      line-height: 1.6;
      white-space: pre-wrap;
      position: relative;
    }
    .prompt-part { color: var(--text-muted); }
    .gen-part { color: #38bdf8; font-weight: 500; }

    .memory-duel {
      background: rgba(15, 23, 42, 0.8);
      border: 1px solid rgba(56, 189, 248, 0.25);
      border-radius: 12px;
      padding: 16px;
      margin-top: 10px;
    }
    .memory-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 0.9rem; }
    .bar-container { height: 10px; background: rgba(255,255,255,0.06); border-radius: 5px; overflow: hidden; margin-top: 4px; }
    .bar-aura { height: 100%; width: 5%; background: var(--success); }
    .bar-tf { height: 100%; width: 85%; background: #ef4444; }

    .spinner {
      display: inline-block;
      width: 18px; height: 18px;
      border: 3px solid rgba(255,255,255,0.3);
      border-radius: 50%;
      border-top-color: #fff;
      animation: spin 0.8s ease-in-out infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="badge">🚀 Arquitectura de IA Propia — v2.1</div>
      <h1>AURA Interactive Studio</h1>
      <p class="subtitle">Adaptive Unitary Resonant Architecture — Red de Ondas Armónicas en el Plano Complejo</p>
    </header>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-title">Estado de Memoria</div>
        <div class="stat-value" style="color: var(--success);">54.0 KB</div>
        <div class="stat-highlight">Constante O(1) [Cero KV-Cache]</div>
      </div>
      <div class="stat-card">
        <div class="stat-title">Complejidad Temporal</div>
        <div class="stat-value" style="color: var(--primary);">O(N) Lineal</div>
        <div class="stat-highlight">9.5x más rápida a 1k tokens</div>
      </div>
      <div class="stat-card">
        <div class="stat-title">Aguja en el Pajar</div>
        <div class="stat-value" style="color: var(--accent);">100.0%</div>
        <div class="stat-highlight">Memoria asociativa perfecta</div>
      </div>
      <div class="stat-card">
        <div class="stat-title">Parámetros Activos</div>
        <div class="stat-value">377,472</div>
        <div class="stat-highlight">3 Bloques Matriciales Resonantes</div>
      </div>
    </div>

    <div class="main-grid">
      <div class="card">
        <h2>✍️ Escribe tu Prompt</h2>
        <textarea id="promptInput" placeholder="Introduce el inicio de una frase...">Había una vez un pequeño robot </textarea>
        
        <div>
          <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 6px;">Prompts Rápidos (Español Moderno):</div>
          <div class="presets">
            <button class="preset-btn" onclick="setPrompt('Había una vez un pequeño robot ')">El pequeño robot...</button>
            <button class="preset-btn" onclick="setPrompt('La inteligencia artificial es ')">Inteligencia artificial...</button>
            <button class="preset-btn" onclick="setPrompt('—Hola, ¿puedes ayudarme con ')">Chat asistente...</button>
            <button class="preset-btn" onclick="setPrompt('En el laboratorio de la universidad ')">El laboratorio...</button>
            <button class="preset-btn" onclick="setPrompt('El cielo nocturno estaba ')">El cielo nocturno...</button>
          </div>
        </div>


        <div class="controls">
          <div class="control-group">
            <label>Tokens a Generar <span class="control-val" id="tokVal">70</span></label>
            <input type="range" id="tokSlider" min="20" max="140" value="70" oninput="document.getElementById('tokVal').innerText = this.value">
          </div>
          <div class="control-group">
            <label>Temperatura <span class="control-val" id="tempVal">0.75</span></label>
            <input type="range" id="tempSlider" min="0.2" max="1.2" step="0.05" value="0.75" oninput="document.getElementById('tempVal').innerText = this.value">
          </div>
        </div>

        <button class="run-btn" id="genBtn" onclick="generate()">
          <span id="btnIcon">⚡</span>
          <span id="btnText">Generar con AURA v2.1</span>
        </button>
      </div>

      <div class="card">
        <h2>🔮 Generación de Texto en Tiempo Real</h2>
        <div class="output-box" id="outputBox">
          <span class="prompt-part">En un lugar de la Mancha</span><span class="gen-part" id="genText">, que, le en la merte y las corazo, en nos alantes, pronsirón con las toda que l...</span>
        </div>

        <div class="memory-duel">
          <div class="memory-row">
            <span><strong>AURA v2.1 (Nuestra):</strong> Memoria Fija</span>
            <span style="color: var(--success); font-weight: 700;" id="auraMem">54.0 KB</span>
          </div>
          <div class="bar-container"><div class="bar-aura"></div></div>

          <div class="memory-row" style="margin-top: 12px;">
            <span><strong>Transformer (ChatGPT):</strong> KV Cache necesario</span>
            <span style="color: #ef4444; font-weight: 700;" id="tfMem">~380.0 KB</span>
          </div>
          <div class="bar-container"><div class="bar-tf" id="tfBar"></div></div>

          <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 12px; display: flex; justify-content: space-between;" id="perfMetrics">
            <span>Latencia: <strong id="latVal">-- ms</strong></span>
            <span>Velocidad: <strong id="spdVal">-- ms/token</strong></span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    function setPrompt(txt) {
      document.getElementById('promptInput').value = txt;
    }

    async function generate() {
      const prompt = document.getElementById('promptInput').value.trim();
      if (!prompt) return;

      const maxTokens = parseInt(document.getElementById('tokSlider').value);
      const temp = parseFloat(document.getElementById('tempSlider').value);

      const btn = document.getElementById('genBtn');
      const btnText = document.getElementById('btnText');
      const btnIcon = document.getElementById('btnIcon');
      btn.disabled = true;
      btnIcon.innerHTML = '<div class="spinner"></div>';
      btnText.innerText = 'Resonando ondas armónicas...';

      const outBox = document.getElementById('outputBox');
      outBox.innerHTML = '<span class="prompt-part">' + escapeHtml(prompt) + '</span><span class="gen-part" id="genText"> [generando...]</span>';

      try {
        const resp = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: prompt, max_tokens: maxTokens, temperature: temp })
        });
        const data = await resp.json();

        outBox.innerHTML = '<span class="prompt-part">' + escapeHtml(prompt) + '</span>' +
                           '<span class="gen-part">' + escapeHtml(data.new_text) + '</span>';

        document.getElementById('latVal').innerText = data.elapsed_ms + ' ms';
        document.getElementById('spdVal').innerText = data.ms_per_token + ' ms/token';
        document.getElementById('tfMem').innerText = data.transformer_kv_kb + ' KB';

        // Ratio bar
        const tfRatio = Math.min(100, Math.max(15, (data.transformer_kv_kb / 500) * 80));
        document.getElementById('tfBar').style.width = tfRatio + '%';

      } catch (err) {
        outBox.innerHTML += '<br><span style="color:#ef4444;">Error de conexión: ' + err + '</span>';
      } finally {
        btn.disabled = false;
        btnIcon.innerText = '⚡';
        btnText.innerText = 'Generar con AURA v2.1';
      }
    }

    function escapeHtml(text) {
      const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
      return text.replace(/[&<>"']/g, m => map[m]);
    }
  </script>
</body>
</html>
"""


class AURAHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_CONTENT.encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == "/api/generate":
            content_len = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_len)
            try:
                body_str = body.decode("utf-8")
            except Exception:
                body_str = body.decode("latin-1", errors="replace")
            
            try:
                data = json.loads(body_str)
                prompt = data.get("prompt", "Habia una vez un pequeno robot ")
                max_tokens = int(data.get("max_tokens", 60))
                temperature = float(data.get("temperature", 0.75))
                result = run_generation(prompt=prompt, max_tokens=max_tokens, temperature=temperature)
            except Exception as e:
                result = {"new_text": f"Error: {e}", "elapsed_ms": 0, "ms_per_token": 0, "aura_memory_kb": 54.0, "transformer_kv_kb": 0}

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(result).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()


    def log_message(self, format, *args):
        # Silence normal request logs for a clean terminal
        pass


def run_server(port=7860):
    server = HTTPServer(("127.0.0.1", port), AURAHandler)
    print("\n=======================================================")
    print(f"  [AURA Studio] Web Dashboard ACTIVO")
    print(f"  Abre tu navegador en: http://localhost:{port}")
    print("=======================================================\n")
    server.serve_forever()



if __name__ == "__main__":
    run_server(port=7860)
